package com.laurachelaru.flexspinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.laurachelaru.flexspinnerlibrary.FlexSingleItem;
import com.laurachelaru.flexspinnerlibrary.FlexSpinnerSingle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FlexSpinnerSingle spinnerSingle = (FlexSpinnerSingle) findViewById(R.id.single_spinner);

        List<FlexSingleItem> singleItemList = new ArrayList<>();
        for (int i = 0; i<10; i++) {
            singleItemList.add(new FlexSingleItem(this, "Item " +String.valueOf(i), i));
        }
    }
}
