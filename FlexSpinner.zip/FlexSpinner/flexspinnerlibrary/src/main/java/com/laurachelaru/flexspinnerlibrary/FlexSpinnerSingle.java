package com.laurachelaru.flexspinnerlibrary;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import com.mikepenz.fastadapter.commons.adapters.FastItemAdapter;

import androidx.appcompat.widget.AppCompatSpinner;

public class FlexSpinnerSingle extends AppCompatSpinner {
    private static final String TAG = FlexSpinnerSingle.class.getSimpleName();

    String defaultSpinnerText, updatableSpinnerText;
    FastItemAdapter<FlexSingleItem> fastAdapter;

    public FlexSpinnerSingle(Context context) {
        super(context);
    }

    public FlexSpinnerSingle(Context arg0, AttributeSet arg1) {
        super(arg0, arg1);
        TypedArray array = arg0.obtainStyledAttributes(arg1, R.styleable.FlexSpinner);
        final int index = array.getIndexCount();
        for (int i = 0; i < index; ++i) {
            int attr = array.getIndex(i);
            if (attr == R.styleable.FlexSpinner_hintText) {
                updatableSpinnerText = array.getString(attr);
                defaultSpinnerText = updatableSpinnerText;
                break;
            }
        }
        //Log.i(TAG, "spinnerTitle: "+ defaultSpinnerText);
        array.recycle();
    }
}
