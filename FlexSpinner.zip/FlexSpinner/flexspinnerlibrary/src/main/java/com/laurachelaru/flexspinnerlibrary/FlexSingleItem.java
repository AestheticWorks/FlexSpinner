package com.laurachelaru.flexspinnerlibrary;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.mikepenz.fastadapter.items.AbstractItem;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FlexSingleItem extends AbstractItem<FlexSingleItem, FlexSingleItem.ViewHolder> {

    protected Activity activity;
    protected String text;
    protected Integer intId;
    protected String stringId;

    public FlexSingleItem(Activity activity, String text) {
        this.activity = activity;
        this.text = text;
    }

    public FlexSingleItem(Activity activity, String text, Integer intId) {
        this.activity = activity;
        this.text = text;
        this.intId = intId;
    }

    public FlexSingleItem(Activity activity, String text, String stringId) {
        this.activity = activity;
        this.text = text;
        this.intId = intId;
    }

    public String getText() {
        return text;
    }

    public Integer getIntId() {
        return intId;
    }

    public String getStringId() {
        return stringId;
    }

    @NonNull
    @Override
    public ViewHolder getViewHolder(View v) {
        return new ViewHolder(v);
    }

    @Override
    public int getType() {
        return R.id.single_item;
    }

    @Override
    public int getLayoutRes() {
        return R.layout.flex_single_item;
    }

    @Override
    public void bindView(ViewHolder viewHolder, List<Object> payloads) {
        //call super so the selection is already handled for you
        super.bindView(viewHolder, payloads);

        viewHolder.text.setText(text);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        protected TextView text;

        ViewHolder(View view) {
            super(view);

            text = view.findViewById(R.id.single_item);
        }
    }
}